import UseState from './components/UseState';

function App() {
  return <UseState />;
}

export default App;
